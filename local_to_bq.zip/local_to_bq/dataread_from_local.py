import mysql.connector
from mysql.connector import Error
import pandas as pd
import json
import mysql.connector
import pandas as pd
from google.cloud import bigquery
import os

from google.cloud.bigquery import schema, table
from google.cloud.client import Client
import pyarrow


class sql_to_bq():
    def __init__(self, path):
        self.path = path
        self.config_data = open(self.path)
        self.data = json.load(self.config_data)
        self.host_name = self.data["host_name"]
        self.user_name = self.data["user_name"]
        self.user_password = self.data["user_password"]
        self.db_name = self.data["db_name"]
        self.q1 = self.data["q1"]

    def create_db_connection(self):
        connection = None
        try:
            self.connection = mysql.connector.connect(
                host=self.host_name,
                user=self.user_name,
                passwd=self.user_password,
                database=self.db_name
            )
            print("MySQL Database connection successful")

        except Error as err:
            print(f"Error: '{err}'")

    def read_query(self):
        cursor = self.connection.cursor()
        result = None
        try:
            cursor.execute(self.q1)
            self.result = cursor.fetchall()
        except Error as err:
            print(f"Error: '{err}'")

    def results_data(self):
        df = pd.DataFrame(self.result)
        return df


class write_to_bq():
    def __init__(self):
        print("hi")


def fetch_data(path):
    sql_bq = sql_to_bq(path)
    sql_bq.create_db_connection()
    sql_bq.read_query()
    result_data = sql_bq.results_data()
    print(result_data)


def write_data(security_key):
    print(security_key)


if __name__ == '__main__':
    path = "C:/Users/surya/PycharmProjects/AMS/processgate1/connections.json"
    security_key = "E:\gcp\key.json"
    fetch_data(path)
    write_data(security_key)
