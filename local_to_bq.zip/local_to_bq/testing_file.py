import mysql.connector
import pandas as pd


mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="Surya@8897",
  database="world"
)

mycursor = mydb.cursor()

mycursor.execute("SELECT * FROM world.city")

myresult = mycursor.fetchall()

df=pd.DataFrame(myresult,columns=["ID","Name","CountryCode","District","Population"])
print(df)

