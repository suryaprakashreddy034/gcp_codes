import pandas as pd

import json
import snowflake.connector
import pandas as pd

# Opening JSON file

def process_data():
    data = pd.read_csv("~/processgate1/business-financial-data-sep-2021-quarter.csv")

    f = open('/usr/local/airflow/processgate1/connections.json')

    # returns JSON object as
    # a dictionary
    data = json.load(f)
    print(data)
    conn = snowflake.connector.connect(
        user="SURYA",
        password="Surya@8897",
        account='pm24169.us-central1.gcp',
        warehouse="AAMSMANAGMENT",
        database="aams",
        schema='public'
    )
    cur = conn.cursor()
    print(cur)
    query = '''select * from AAMS.PUBLIC.TESTTABLE'''
    cur.execute(query)
    data = pd.DataFrame.from_records(iter(cur), columns=[x[0] for x in cur.description])
    print(data)
    cur.close()