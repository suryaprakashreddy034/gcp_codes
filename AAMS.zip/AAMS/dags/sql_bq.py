import json
import pandas as pd

import os
import pytz
from datetime import datetime
import snowflake.connector
#from google.cloud import bigquery
from google.cloud import bigquery

def main_fun():
    class SplitRow():
        def __init__(self, element):

            self.path_data = open(element)
            self.data = json.load(self.path_data)
        def d1(self):
            self.q1 = self.data["q1"]
            self.user = self.data["user"]
            self.password = self.data["password"]
            self.warehouse = self.data["warehouse"]
            self.database = self.data["database"]
            self.schema = self.data["schema"]
            self.account = self.data["account"]
            conn = snowflake.connector.connect(
                user=self.user,
                password=self.password,
                account=self.account,
                warehouse=self.warehouse,
                database=self.database,
                schema=self.schema
            )
            cur = conn.cursor()
            cur.execute("""{}""".format(self.q1))
            data = pd.DataFrame.from_records(iter(cur), columns=['c1', 'c2', 'c3'])
            print(data)
            cur.close()

            return data

    class FilterAccountsEmployee():
        def __init__(self, inputkey, element):
            self.key = inputkey
            self.table_data = element
            print(self.key)
            #client = bigquery.Client()


        def start_bundle(self):
            os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = self.key
            self.client = bigquery.Client()
            print(self.client)
            self.table_id = "mapapi-290312.sql_data.spr"
            # bigquery.Client()


        def process(self):
            self.dataframe = pd.DataFrame(self.table_data)
            ist = pytz.timezone('Asia/Calcutta')

            print('Current Date and Time in IST =', datetime.now(ist))
            timenow = datetime.now(ist)
            self.dataframe["bqload_time"] = timenow
            print(self.dataframe)

            # "ID", "moviename", "actor", "releasedate"

            schema = [bigquery.SchemaField("c1", "STRING", mode="NULLABLE"),
                      bigquery.SchemaField("c2", "STRING", mode="NULLABLE"),
                      bigquery.SchemaField("c3", "STRING", mode="NULLABLE"),
                      #bigquery.SchemaField("releasedate", "STRING", mode="NULLABLE"),
                      bigquery.SchemaField("bqload_time", "STRING", mode="NULLABLE")]
            job_config = bigquery.LoadJobConfig(schema=schema)
            df = self.dataframe.astype(str)
            self.client.load_table_from_dataframe(df, self.table_id, job_config=job_config).result()
            for row in df.iterrows():
                print(row)
            





    inputpath = '/usr/local/airflow/processgate1/connections.json'
    keypath = "/usr/local/airflow/processgate1/key.json"

    c1 = SplitRow(inputpath)
    res=c1.d1()
    c2=FilterAccountsEmployee(keypath,res)
    c2.start_bundle()
    c2.process()
