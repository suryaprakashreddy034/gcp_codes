# -*- coding: utf-8 -*-
"""
Created on Sat Jul  3 01:54:51 2021

@author: viswa
"""

from airflow import DAG
from datetime import datetime,timedelta
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import PythonOperator


from filecheck import process_data
from sql_bq import main_fun


default_args = {"owner":"airflow","start_date":datetime(2022,1,22)}
with DAG(dag_id="workflow",default_args=default_args,schedule_interval='@daily') as dag:
   
    check_key_file = BashOperator(
        task_id="checking_key_file",
        bash_command="shasum ~/processgate1/key.json",
        retries = 2,
        retry_delay=timedelta(seconds=15))
    check_conf_file = BashOperator(
        task_id="checking_conf_file",
        bash_command="shasum ~/processgate1/connections.json",
        retries = 2,
        retry_delay=timedelta(seconds=15))
    
    pre_process = PythonOperator(
        task_id = "pre_process",
        python_callable = process_data
        )
    sql_process = PythonOperator(
        task_id = "sql_process",
        python_callable = main_fun
        )
    


    check_key_file >> check_conf_file >> pre_process >> sql_process